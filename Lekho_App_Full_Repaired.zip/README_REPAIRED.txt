# लेखो ऐप — repaired project

यह पैकेज मौजूदा लेखो ऐप को दोबारा शुरू से नहीं बनाता। इसमें आपकी मौजूदा पूर्ण `index.html` को रखते हुए:
- Sign Up → Sign In navigation fix
- localStorage/sessionStorage save/load verification
- account save failure handling
- मौजूदा Stock, Sale, Khata और Reports code को बरकरार रखा गया है

नोट: Firebase `google-services.json` इस पैकेज में शामिल है क्योंकि मौजूदा repo में यह file मौजूद थी।
